import * as React from 'react';
import dayjs from 'dayjs';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';

interface DatePickerValueProps {
	onClose: () => void;
}

const Popup: React.FC<DatePickerValueProps> = () => {
	return (
		<LocalizationProvider dateAdapter={AdapterDayjs}>
			<DemoContainer components={['DatePicker', 'DatePicker']}>
				<DatePicker label='Uncontrolled picker' defaultValue={dayjs('2022-04-17')} />
				<FormControl>
					<FormLabel id='demo-radio-buttons-group-label'>Gender</FormLabel>
					<RadioGroup
						aria-labelledby='demo-radio-buttons-group-label'
						defaultValue='female'
						name='radio-buttons-group'
					>
						<FormControlLabel value='Option1' control={<Radio />} label='Option1' />
						<FormControlLabel value='Option2' control={<Radio />} label='Option2' />
						<FormControlLabel value='Option3' control={<Radio />} label='Option3' />
					</RadioGroup>
				</FormControl>
			</DemoContainer>
		</LocalizationProvider>
	);
};

export default Popup;
