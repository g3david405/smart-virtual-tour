import React, { useState } from 'react';
import DatePickerValue from './Popup';

export const DateFilter: React.FC = () => {
	const [isPopupOpen, setPopupOpen] = useState(false);

	const openPopup = () => {
		setPopupOpen(true);
	};

	const closePopup = () => {
		setPopupOpen(false);
	};

	return (
		<div>
			<button onClick={openPopup}>Open Popup</button>
			{isPopupOpen && <DatePickerValue onClose={closePopup} />}
		</div>
	);
};
